
#!/bin/bash
cd /root/proxy


ss -tunlp|grep -w 5000 > /dev/null || {  screen -r -S checkuser -X quit; screen -dmS checkuser /root/proxy/checkuser ; }